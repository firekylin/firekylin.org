'use strict';

/**
 * hook config
 * https://thinkjs.org/doc/middleware.html#toc-df6
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {};