const adminAuth = require('../../service/admin-auth');
const fs = require('fs');
const path = require('path');
const {version} = require('../../../package.json');

let adminAssetVersion;

function getAdminAssetVersion() {
  if (adminAssetVersion) return adminAssetVersion;
  try {
    const versionPath = path.join(think.ROOT_PATH, 'www/static/dist/assets/admin.version');
    adminAssetVersion = fs.readFileSync(versionPath, 'utf8').trim();
    return adminAssetVersion;
  } catch (e) {
    // Keep development usable before the first frontend build. A release always
    // contains admin.js, enforced by the packaging workflow.
    return version;
  }
}

module.exports = class extends think.Controller {
  async __before() {
    const { controller, action } = this.ctx;
    if (controller === 'admin/user' && action === 'login') {
      return;
    }

    const authOptions = await this.model('options').getOptions(true);
    this.authOptions = authOptions;
    this.ctx.state.jwtSecret = authOptions.jwt_secret || authOptions.comment_jwt_secret;
    const userInfo = adminAuth.currentUser(this.ctx) || {};
    if (think.isEmpty(userInfo)) {
      if (this.isAjax()) {
        return this.fail('NOT_LOGIN');
      }
    }
    this.userInfo = userInfo;
    if (!this.isAjax()) {
      this.assign('userInfo', { id: userInfo.id, name: userInfo.name, type: userInfo.type });
    }
  }

  async __call() {
    if (this.isAjax()) {
      return this.fail('ACTION_NOT_FOUND');
    }
    let options = {...this.authOptions};
    delete options.jwt_secret;
    delete options.comment_jwt_secret;
    delete options.comment_schema_version;
    // 不显示具体的密钥
    options.two_factor_auth = !!options.two_factor_auth;
    options.analyze_code = escape(options.analyze_code);
    try {
      options.navigation = JSON.parse(options.navigation);
    } catch (e) { options.navigation = [] }
    delete options.push_sites; // 不显示推送的配置，会有安全问题
    try {
      options.social_services = await this.service('social-auth').services();
    } catch {
      options.social_services = [];
    }

    if (firekylin.require('auth')) {
      options.intranet = true;
    }

    if (think.isEmpty(this.userInfo)) {
      options = {
        title: options.title,
        favicon_url: options.favicon_url,
        two_factor_auth: options.two_factor_auth,
        password_salt: options.password_salt,
        ldap_on: options.ldap_on,
        intranet: options.intranet,
        social_services: options.social_services
      };
    }

    this.assign('options', options);
    this.assign('think', think);
    this.assign('adminAssetVersion', getAdminAssetVersion());
    this.assign('csrfToken', adminAuth.csrfToken(this.ctx));

    return this.display('admin');
  }
};
