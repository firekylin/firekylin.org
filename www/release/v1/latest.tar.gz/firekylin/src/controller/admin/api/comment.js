'use strict';


const Base = require('./base');
const CommentModerationService = require('../../../service/comment-moderation');
const permalink = require('../../../service/permalink');

module.exports = class extends Base {
  async getAction() {
    const page = Math.max(Number(this.get('page')) || 1, 1);
    const pageSize = Math.min(Math.max(Number(this.get('pageSize')) || 20, 1), 100);
    const status = this.get('status');
    const keyword = String(this.get('keyword') || '').trim();
    const author = String(this.get('author') || '').trim();
    const where = status ? {status} : {};
    if (Number(this.userInfo.type) === 4) where.user_id = String(this.userInfo.id);
    if (keyword) where.comment = ['LIKE', `%${keyword}%`];
    if (author) {
      const pattern = `%${author}%`;
      const matchedUsers = await this.model('user').where({
        name: ['LIKE', pattern],
        display_name: ['LIKE', pattern],
        email: ['LIKE', pattern],
        _logic: 'OR'
      }).field('id')
        .select();
      where._complex = {
        nick: ['LIKE', pattern],
        mail: ['LIKE', pattern],
        ip: ['LIKE', pattern],
        ...(matchedUsers.length ? {user_id: ['IN', matchedUsers.map(user => String(user.id))]} : {}),
        _logic: 'OR'
      };
    }
    const model = this.model('comment');
    const [total, data] = await Promise.all([
      model.where(where).count(),
      model.where(where).order('inserted_at DESC').page(page, pageSize)
        .select()
    ]);
    const userIds = [...new Set(data.map(item => item.user_id).filter(Boolean))];
    const postIds = [...new Set(data.map(item => Number(item.post_id)).filter(Boolean))];
    const [users, posts] = await Promise.all([
      userIds.length ? this.model('user').where({id: ['IN', userIds]}).field('id,name,display_name,email,url,avatar')
        .select() : [],
      postIds.length ? this.model('post').where({id: ['IN', postIds]}).field('id,title,pathname,type,create_time')
        .select() : []
    ]);
    const userMap = new Map(users.map(user => [String(user.id), user]));
    const postMap = new Map(posts.map(post => [Number(post.id), post]));
    const rows = data.map(item => {
      const user = userMap.get(String(item.user_id)) || {};
      const email = user.email || item.mail || '';
      const post = postMap.get(Number(item.post_id));
      const postUrl = post ? permalink.generate(post.type, post, this.authOptions) : item.url;
      return {
        ...item,
        author_name: user.display_name || user.name || item.nick || '匿名',
        author_email: email,
        author_link: user.url || item.link || '',
        author_avatar: user.avatar || `https://seccdn.libravatar.org/avatar/${think.md5(String(email).toLowerCase())}?d=mp`,
        post_title: post ? post.title : item.url,
        post_url: postUrl
      };
    });
    return this.success({page, pageSize, total: Number(total), keyword, author, data: rows});
  }

  async postAction() {
    const id = Number(this.post('id'));
    if (!Number.isSafeInteger(id) || id <= 0) return this.fail('PARAMS_ERROR');
    const service = new CommentModerationService({
      getModel: name => this.model(name),
      now: () => think.datetime(),
      syncCount: postId => this.service('comment').syncCount(this, postId),
      notifyApprovedReply: comment => this.service('comment').notifyApprovedReply(this, comment)
    });
    try {
      await service.moderate({
        id, operation: this.post('operation'), comment: this.post('comment'), allowCommenter: true
      }, this.userInfo);
    } catch (error) {
      if (['COMMENT_NOT_FOUND', 'INVALID_OPERATION', 'USER_NO_PERMISSION'].includes(error.message)) {
        return this.fail(error.message);
      }
      throw error;
    }
    return this.success();
  }
};
