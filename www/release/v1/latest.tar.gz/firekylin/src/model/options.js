module.exports = class extends think.Model {
  get pk() {
    return 'key';
  }

  /**
   * get options
   * @return {} []
   */
  async getOptions(includePrivate = false) {
    const data = await this.select();
    const ret = {};
    data.forEach(item => {
      ret[item.key] = item.value;
    });
    if (!includePrivate) {
      delete ret.comment_jwt_secret;
      delete ret.comment_schema_version;
    }

    // comment type
    if (think.isEmpty(ret)) {
      return {};
    }

    if (ret.comment && think.isString(ret.comment)) {
      ret.comment = JSON.parse(ret.comment);
    }
    const comment = {...(ret.comment || {})};
    Reflect.deleteProperty(comment, 'name');
    Reflect.deleteProperty(comment, 'type');
    ret.comment = {
      audit: false,
      forceLogin: false,
      pageSize: 10,
      locale: 'zh-CN',
      ipQps: 60,
      commentSorting: 'latest',
      dark: false,
      meta: ['nick', 'mail', 'link'],
      requiredMeta: [],
      wordLimit: 0,
      emoji: true,
      reaction: false,
      imageUploader: true,
      highlighter: true,
      texRenderer: true,
      search: true,
      noCopyright: false,
      noRss: false,
      forbiddenWords: [],
      disallowIPList: [],
      likeIncMax: 1,
      levels: [],
      avatarProxy: '',
      ...comment
    };
    // upload settings
    if (ret.upload && think.isString(ret.upload)) {
      ret.upload = JSON.parse(ret.upload);
    }
    if (!ret.upload) {
      ret.upload = {type: 'local'};
    }
    if (ret.push_sites && think.isString(ret.push_sites)) {
      ret.push_sites = JSON.parse(ret.push_sites);
    }
    if (!ret.push_sites) {
      ret.push_sites = {};
    }
    if (ret.rssImportList && think.isString(ret.rssImportList)) {
      ret.rssImportList = JSON.parse(ret.rssImportList);
    }
    if (!ret.rssImportList) {
      ret.rssImportList = [];
    }
    return ret;
  }
  /**
   * update options
   * @return {} []
   */
  async updateOptions(key, value) {
    const data = think.isObject(key) ? think.extend({}, key) : {[key]: value};
    const promises = [];
    for (const key in data) {
      const value = data[key];
      const exist = await this.where({key: key}).count('key');
      let p;
      if (Number(exist) > 0) {
        p = this.where({key: key}).update({value: value});
      } else {
        p = this.add({key, value});
      }
      promises.push(p);
    }
    await Promise.all(promises);
    await this.getOptions();

    // if `auto_summary` is changed, then rebuild all summaries of posts
    if (typeof data.auto_summary !== 'undefined') {
      const postModel = think.model('post');
      // doesn't wait for return
      await postModel.updateAllPostSummaries();
    }
  }
};
