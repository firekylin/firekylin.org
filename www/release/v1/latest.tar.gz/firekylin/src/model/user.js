const { PasswordHash } = require('phpass');
const Base = require('./base');
const {emit, filter} = require('../plugin/runtime');

module.exports = class extends Base {
  /**
   * get password
   * @param  {String} username []
   * @param  {String} salt     []
   * @return {String}          []
   */
  getEncryptPassword(password) {
    const passwordHash = new PasswordHash();
    const hash = passwordHash.hashPassword(password);
    return hash;
  }
  /**
   * check password
   * @param  {[type]} userInfo [description]
   * @param  {[type]} password [description]
   * @return {[type]}          [description]
   */
  checkPassword(userInfo, password) {
    const passwordHash = new PasswordHash();
    return passwordHash.checkPassword(password, userInfo.password);
  }

  generateKey(userId, app_key, app_secret, status) {
    const data = { app_key, app_secret };
    if (status) { data.status = status }
    this.where({ id: userId }).update(data);
  }

  /**
   * after select
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  afterSelect(data) {
    return data.map(item => {
      return this.afterFind(item);
    });
  }
  afterFind(data) {
    if (data.create_time) {
      data.create_time = think.datetime(new Date(data.create_time));
    }
    if (data.last_login_time) {
      data.last_login_time = think.datetime(new Date(data.last_login_time));
    }
    return data;
  }
  /**
   * 添加用户
   * @param {[type]} data [description]
   * @param {[type]} ip   [description]
   */
  async addUser(data, ip) {
    const create_time = think.datetime();
    const encryptPassword = this.getEncryptPassword(data.password);
    const prepared = await filter('user.beforeCreate', {...data, ip}, {ip});
    const user = {
      name: prepared.username,
      email: prepared.email,
      display_name: prepared.display_name,
      password: encryptPassword,
      create_time: create_time,
      last_login_time: create_time,
      create_ip: ip,
      last_login_ip: ip,
      type: prepared.type,
      status: prepared.status
    };
    const result = await this.where({ name: prepared.username, email: prepared.email, _logic: 'OR' }).thenAdd(user);
    await emit('user.created', {user: result || user});
    return result;
  }
  /**
   * 保存用户信息
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  async saveUser(data, ip) {
    const info = await this.where({ id: data.id }).find();
    if (think.isEmpty(info)) {
      return Promise.reject(new Error('UESR_NOT_EXIST'));
    }
    let password = data.password;
    if (password) {
      password = this.getEncryptPassword(password);
    }
    const updateData = {};
    ['display_name', 'type', 'status'].forEach(item => {
      if (data[item]) {
        updateData[item] = data[item];
      }
    });
    if (password) {
      updateData.password = password;
    }
    if (data.email) {
      const count = await this.where({ email: data.email }).count('email');
      if (Number(count) === 0) {
        updateData.email = data.email;
      }
    }
    if (think.isEmpty(updateData)) {
      return Promise.reject('DATA_EMPTY');
    }
    updateData.last_login_time = think.datetime();
    updateData.last_login_ip = ip;
    return this.where({ id: data.id }).update(updateData);
  }

  /**
   * 更新用户的登录时间
   * @param {object} user 用户信息
   */
  async updateUserLoginTime(user) {
    return this.where({ id: user.id }).update({
      last_login_time: think.datetime()
    });
  }
};
