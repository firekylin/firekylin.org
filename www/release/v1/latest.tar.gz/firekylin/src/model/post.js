const {renderMarkdown} = require('../service/markdown');
const Base = require('./base');
const {emit, filter} = require('../plugin/runtime');

function redactProtectedPosts(posts) {
  return posts.map(post => {
    let options = post.options || {};
    if (typeof options === 'string') {
      try { options = JSON.parse(options) || {} } catch { options = {} }
    }
    if (!options.postPasswordHash) return post;
    delete options.postPasswordHash;
    return Object.assign({}, post, {
      title: '此内容被密码保护',
      summary: '这篇文章受密码保护。',
      content: '这篇文章受密码保护。',
      options
    });
  });
}

module.exports = class extends Base {
  get relation() {
    return {
      tag: think.Model.MANY_TO_MANY,
      cate: think.Model.MANY_TO_MANY,
      user: {
        type: think.Model.BELONG_TO,
        // fKey: 'user_id',
        // key: 'display_name',
        field: 'id,name,display_name'
      }
    };
  }

  /**
   * 添加文章
   * @param {[type]} data [description]
   * @param {[type]} ip   [description]
   */
  async addPost(data) {
    const create_time = think.datetime();
    data = Object.assign({
      type: 0,
      status: 0,
      create_time,
      update_time: create_time,
      is_public: 1
    }, data);

    const prepared = await filter('content.beforeCreate', data, {type: 'post'});
    const result = await this.where({ pathname: prepared.pathname }).thenAdd(prepared);
    const post = result || prepared;
    await emit('post.created', {post});
    await emit('content.created', {post});
    return result;
  }

  async savePost(data) {
    const info = await this.where({ id: data.id }).find();
    if (think.isEmpty(info)) {
      return Promise.reject(new Error('POST_NOT_EXIST'));
    }

    // ThinkJS 的 MANY_TO_MANY 关联处理器会跳过空数组（isEmpty([]) === true），
    // 导致无法清除已有的分类和标签关联。这里手动删除空数组对应的关联记录。
    if (Array.isArray(data.cate) && data.cate.length === 0) {
      await this.model('post_cate').where({ post_id: data.id }).delete();
      delete data.cate;
    }
    if (Array.isArray(data.tag) && data.tag.length === 0) {
      await this.model('post_tag').where({ post_id: data.id }).delete();
      delete data.tag;
    }

    data.update_time = think.datetime();
    const prepared = await filter('content.beforeUpdate', data, {type: 'post'});
    const result = await this.where({ id: data.id }).update(prepared);
    await emit('post.updated', {post: prepared, result});
    await emit('content.updated', {post: prepared, result});
    return result;
  }

  async deletePost(post_id) {
    // await this.model('post_cate').delete({post_id});
    // await this.model('post_tag').delete({post_id});
    await emit('post.beforeDelete', {id: post_id});
    const result = await this.where({ id: post_id }).delete();
    await emit('post.deleted', {id: post_id, result});
    return result;
  }

  /**
   * get count posts
   * @param  {Number} userId []
   * @return {Promise}        []
   */
  getCount(userId) {
    if (userId) {
      return this.where({ user_id: userId }).count();
    }
    return this.count();
  }
  /**
   * get latest posts
   * @param  {Number} nums []
   * @return {}      []
   */
  getLatest(user_id, nums = 10) {
    const where = {
      create_time: { '<=': think.datetime() },
      is_public: 1, // 公开
      type: 0, // 文章
      status: 3 // 已经发布
    };
    if (user_id) { where.user_id = user_id }
    return this.order('id DESC')
      .where(where)
      .limit(nums)
      .setRelation(false)
      .order('create_time DESC')
      .select();
  }

  async afterUpdate(data, options) {
    await super.afterUpdate(data, options);
    return this.clearCache();
  }

  async afterDelete(data, options) {
    await super.afterDelete(data, options);
    return this.clearCache();
  }

  async afterAdd(data, options) {
    await super.afterAdd(data, options);
    return this.clearCache();
  }

  async clearCache() {
    think.logger.debug('clear cache');
    await think.cache('post_1', null);
    await think.cache('lastPostList', null);
  }

  /**
   * 更新所有文章的摘要信息并重新保存到数据库
   *
   * @returns {Promise.<void>}
   */
  async updateAllPostSummaries() {
    // get all posts' id and mark down content
    const posts = await this.field('id, markdown_content, summary').setRelation(false).select();
    const allPromises = [];

    if (posts.length > 0) {
      for (let i = 0; i < posts.length; i++) {
        const item = posts[i];
        if (typeof item.summary === 'string' && item.summary.trim()) continue;
        const summary = await this.getSummary(item.markdown_content);

        allPromises.push(this.where({ id: item.id }).update({ summary }));
      }

      await Promise.all(allPromises);
    }
  }

  /**
   * 渲染 markdown
   * 摘要为部分内容时不展示 TOC
   * 文章正文设置为手动指定 TOC 时不显示
   * 页面不自动生成 TOC 除非是手动指定了
   */
  async getContentAndSummary(data) {
    const options = await this.model('options').getOptions();
    const rendered = await this.renderContent(data, options);
    const markdown = rendered.markdown;
    const auto_summary = parseInt(options.auto_summary);
    data.content = rendered.content;
    if (typeof data.summary !== 'string' || !data.summary.trim()) {
      data.summary = await this.getSummary(markdown, auto_summary);
    }

    data.summary = await filter('content.excerpt', data.summary, {post: data});
    data.summary = await filter('content.render', data.summary, {post: data, type: 'summary'});
    return data;
  }

  /**
   * 使用文章正文的完整渲染链路生成 HTML。
   * 后台预览和文章保存共用此方法，避免两端的 Markdown 能力产生差异。
   */
  async renderContent(data, options) {
    options = options || await this.model('options').getOptions();
    const postTocManual = options.postTocManual === '1';
    const hasTocMarker = /(?:^|[\r\n]+)\s*<!--toc-->\s*[\r\n]+/i.test(data.markdown_content);
    const showToc = postTocManual ? hasTocMarker : data.type / 1 === 0 || hasTocMarker;
    const markdown = await filter('content.markdown', data.markdown_content, {post: data});
    data.content = await this.markdownToHtml(markdown, {toc: showToc, highlight: true});
    data.content = await filter('content.html', data.content, {post: data});
    data.content = await filter('content.render', data.content, {post: data, type: 'content'});
    return {content: data.content, markdown};
  }

  /**
   * 渲染 markdown 并返回摘要内容
   * 区别于 getContentAndSummary 方法，此方法只处理和返回摘要
   *
   * @param markdown_content MarkDown 内容
   * @param summary_length 摘要长度（可为空）
   * @return {string}
   */
  async getSummary(markdown_content, summary_length) {
    let summary;

    if (!summary_length) {
      const options = await this.model('options').getOptions();
      summary_length = parseInt(options.auto_summary);
    }

    const hasMoreTag = /(?:^|[\r\n]+)\s*<!--more-->\s*[\r\n]+/i.test(markdown_content);

    if (hasMoreTag || summary_length === 0) {
      summary = markdown_content.split('<!--more-->')[0];
      summary = await this.markdownToHtml(summary, { toc: false, highlight: true });
      summary.replace(/<[>]*>/g, '');
    } else {
      summary = await this.markdownToHtml(markdown_content, { toc: false, highlight: true });
      // 过滤掉 HTML 标签 及换行等 并截取所需的长度
      // 增加过滤 svg 内容
      summary = summary
        .replace(/[\n\r\t]/g, '')
        .replace(/<svg[ >].*?<\/svg>/g, '')
        .replace(/<\/?[^>]*>/g, '')
        .substr(0, summary_length) + '...';
    }

    return summary;
  }

  /**
   * markdown to html
   * @return {string}
   */
  async markdownToHtml(content, option = { toc: true, highlight: true }) {
    return renderMarkdown(content, {
      ...option,
      slugify: this.generateTocName.bind(this),
      renderToc: entries => `<div class="toc">${this.buildTocHtml(entries)}</div>`
    });
  }

  /**
   * 获取文章创建时间
   *
   * @param data
   * @returns {*}
   */
  getPostTime(data) {
    data.update_time = think.datetime();
    if (!data.create_time) {
      data.create_time = data.update_time;
    } else {
      data.create_time = think.datetime(data.create_time);
    }
    return data;
  }

  /**
   * generate toc name
   * @param  {String} name []
   * @return {String}      []
   */
  generateTocName(name) {
    name = name.trim()
      .replace(/\s+/g, '')
      .replace(/\)/g, '')
      .replace(/[(,]/g, '-')
      .toLowerCase();
    if (/^[\w-]+$/.test(name)) {
      return name;
    }
    return `toc-${think.md5(name).slice(0, 3)}`;
  }

  /**
   * 从 tocEntries 生成嵌套 ul>li 目录 HTML
   * @param  {Array} entries [{id, content, level}]
   * @return {string}
   */
  buildTocHtml(entries) {
    if (!entries.length) return '';
    const minLevel = Math.min(...entries.map(e => e.level));
    let html = '<ul>';
    let currentLevel = minLevel;
    for (const entry of entries) {
      while (currentLevel < entry.level) {
        html += '<ul>';
        currentLevel++;
      }
      while (currentLevel > entry.level) {
        html += '</ul>';
        currentLevel--;
      }
      html += `<li><a href="#${entry.id}">${entry.content}</a></li>`;
    }
    while (currentLevel > minLevel) {
      html += '</ul>';
      currentLevel--;
    }
    html += '</ul>';
    return html;
  }

  async getFeedFullText() {
    const {feedFullText} = await this.model('options').getOptions();
    return feedFullText;
  }

  async getPostsListSize() {
    const {postsListSize} = await this.model('options').getOptions();
    return +postsListSize;
  }

  /**
   * get where condition
   * @param  {[type]} where [description]
   * @return {[type]}       [description]
   */
  getWhereCondition(where) {
    where = think.extend({}, where, {
      is_public: 1, // 公开
      type: 0, // 文章
      status: 3 // 已经发布
    });
    if (!where.create_time) {
      where.create_time = {
        '<=': think.datetime()
      };
    }
    return where;
  }

  /**
   * 获取最近的10条数据 - 有缓存
   *
   * @return {Promise}
   */
  getLastPostList() {
    return think.cache('lastPostList', async() => {
      const postList = await this.getPostList();
      return postList.data;
    });
  }

  /**
   * get post list
   * @param  {[type]} page  [description]
   * @param  {[type]} where [description]
   * @return {[type]}       [description]
   */
  async getPostList(page, options = {}) {
    page = page | 0 || 1;
    const postsListSize = Number(options.pageSize) || await this.getPostsListSize();

    const field = (options.field || 'id,title,pathname,create_time,summary,comment_num,options') + ',user_id';

    if (options.tag || options.cate) {
      const name = options.tag ? 'tag' : 'cate';
      const {id} = await this.model(name)
        .field('id')
        .setRelation(false)
        .where({pathname: options.tag || options.cate})
        .find();
      if (think.isEmpty(id)) {
        return false;
      }
      const where = this.getWhereCondition({[`${name}.${name}_id`]: id});
      const result = await this
        .join({
          table: `post_${name}`,
          as: name,
          on: ['id', 'post_id']
        })
        .where(where)
        .order('create_time DESC')
        .page(page, postsListSize)
        .countSelect();
      result.data = redactProtectedPosts(result.data);
      return result;
    }

    const where = this.getWhereCondition(options.where);
    // only cache first page post
    // if(page === 1){
    //   return think.cache('post_1', () => {
    //     return this.field(field)
    //       .page(page, postsListSize)
    //       .setRelation(false)
    //       .order('create_time DESC')
    //       .where(where)
    //       .countSelect();
    //   },{timeout:259200});
    // }

    const result = await this.field(field)
      .page(page, postsListSize)
      .setRelation('user')
      .order('create_time DESC')
      .where(where)
      .countSelect();
    result.data = redactProtectedPosts(result.data);
    return result;
  }

  /**
   * get post detail info
   * @param  {[type]} pathname [description]
   * @return {[type]}          [description]
   */
  async getPostDetail(pathname) {
    const where = this.getWhereCondition({pathname});
    const detail = await this.where(where).fieldReverse('markdown_content,summary').find();
    if (think.isEmpty(detail)) {
      return detail;
    }
    const createTime = think.datetime(detail.create_time);
    const prevWhere = this.getWhereCondition({
      create_time: ['<', createTime],
      id: ['!=', detail.id]
    });
    const prevPromise = this.field('id,title,pathname,create_time,options')
      .setRelation(false)
      .where(prevWhere)
      .order('create_time DESC')
      .find();
    const nextWhere = this.getWhereCondition({
      create_time: ['>', createTime],
      id: ['!=', detail.id]
    });
    const nextPromise = this.field('id,title,pathname,create_time,options')
      .setRelation(false)
      .where(nextWhere)
      .order('create_time ASC')
      .find();
    const [prev, next] = await Promise.all([prevPromise, nextPromise]);
    detail.prev = redactProtectedPosts([prev]).map(item => ({
      id: item.id, title: item.title, pathname: item.pathname, create_time: item.create_time
    }))[0];
    detail.next = redactProtectedPosts([next]).map(item => ({
      id: item.id, title: item.title, pathname: item.pathname, create_time: item.create_time
    }))[0];
    return detail;
  }
  async getPostRssList() {
    let field = 'id,title,pathname,create_time,';
    const where = this.getWhereCondition();
    const feedFullText = await this.getFeedFullText();

    if (feedFullText === '0') {
      field += 'summary,content,options';
    } else {
      field += 'content,options';
    }

    const data = await this.field(field)
      .where(where)
      .order('create_time DESC')
      .setRelation(false)
      .limit(10)
      .select();
    return redactProtectedPosts(data);
  }

  async getPostSitemapList() {
    const field = 'id,pathname,type,create_time,update_time';
    const where = {
      is_public: 1, // 公开
      status: 3, // 已经发布
      create_time: {
        '<=': think.datetime()
      }
    };

    const data = await this.field(field)
      .where(where)
      .order('update_time DESC')
      .setRelation(false)
      .select();
    return data;
  }
  /**
   * get post archive
   * @return {[type]} [description]
   */
  async getPostArchive() {
    const where = this.getWhereCondition();
    const data = await this.field('id,title,pathname,create_time,options')
      .order('create_time DESC')
      .setRelation(false)
      .where(where)
      .select();
    const result = {};
    redactProtectedPosts(data).forEach(item => {
      const yearMonth = think.datetime(item.create_time, 'YYYY年MM月');
      if (!(yearMonth in result)) {
        result[yearMonth] = [];
      }
      result[yearMonth].push(item);
    });
    return result;
  }
  /**
   * get post search result
   * @param  {[type]} keyword [description]
   * @param  {[type]} page    [description]
   * @return {[type]}         [description]
   */
  async getPostSearch(keyword, page) {
    let where = {'title|content': ['LIKE', `%${keyword}%`]};
    where = this.getWhereCondition(where);
    const result = await this.where(where)
      .page(page, await this.getPostsListSize())
      .setRelation(false)
      .field('id,title,pathname,summary,create_time,options')
      .order('create_time DESC')
      .countSelect(false);
    result.data = redactProtectedPosts(result.data);
    return result;
  }
};
