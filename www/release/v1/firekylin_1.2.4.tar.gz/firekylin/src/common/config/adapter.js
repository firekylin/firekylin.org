exports.cache = require('./adapter/cache');
exports.model = require('./adapter/model');
exports.session = require('./adapter/session');
exports.view = require('./adapter/view');
exports.logger = require('./adapter/logger');
