'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  admin: {
    reg: /^admin/
  },
  home: {}
};