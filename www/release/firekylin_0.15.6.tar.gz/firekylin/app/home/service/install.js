'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _getPrototypeOf = require('babel-runtime/core-js/object/get-prototype-of');

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require('babel-runtime/helpers/createClass');

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_think$service$base) {
  (0, _inherits3.default)(_class, _think$service$base);

  function _class() {
    (0, _classCallCheck3.default)(this, _class);
    return (0, _possibleConstructorReturn3.default)(this, (_class.__proto__ || (0, _getPrototypeOf2.default)(_class)).apply(this, arguments));
  }

  (0, _createClass3.default)(_class, [{
    key: 'init',

    /**
     * init
     * @param  {[type]} info [description]
     * @return {[type]}      [description]
     */
    value: function init(dbConfig, accountConfig, ip) {
      this.dbConfig = dbConfig;
      this.dbConfig.type = 'mysql';
      this.accountConfig = accountConfig;
      this.ip = ip;
    }
    /**
     * get model
     * @return {[type]} [description]
     */

  }, {
    key: 'getModel',
    value: function getModel(name, module) {
      var dbConfig = void 0;
      if (name === true) {
        dbConfig = think.extend({}, this.dbConfig);
        dbConfig.database = '';
        name = '';
      } else {
        dbConfig = this.dbConfig;
      }
      return this.model(name || 'user', {
        adapter: {
          mysql: dbConfig
        }
      }, module);
    }
    /**
     *
     * @return {[type]} [description]
     */

  }, {
    key: 'checkDbInfo',
    value: function checkDbInfo() {
      var dbInstance = this.getModel(true);
      return dbInstance.query('SELECT VERSION()').catch(function () {
        return _promise2.default.reject('数据库信息有误');
      });
    }
    /**
     * insert data
     * @return {[type]} [description]
     */

  }, {
    key: 'insertData',
    value: function () {
      var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee() {
        var _this2 = this;

        var model, dbExist, dbFile, content, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, item, promises, optionsModel, salt;

        return _regenerator2.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                model = this.getModel(true);
                _context.next = 3;
                return model.query('SELECT `TABLE_NAME` FROM `INFORMATION_SCHEMA`.`TABLES` WHERE `TABLE_SCHEMA`=\'' + this.dbConfig.database + '\'');

              case 3:
                dbExist = _context.sent;

                if (!think.isEmpty(dbExist)) {
                  _context.next = 7;
                  break;
                }

                _context.next = 7;
                return model.query('CREATE DATABASE `' + this.dbConfig.database + '`').catch(function () {});

              case 7:
                dbFile = think.ROOT_PATH + think.sep + 'firekylin.sql';

                if (think.isFile(dbFile)) {
                  _context.next = 10;
                  break;
                }

                return _context.abrupt('return', _promise2.default.reject('数据库文件（firekylin.sql）不存在，请重新下载'));

              case 10:
                content = _fs2.default.readFileSync(dbFile, 'utf8');

                content = content.split('\n').filter(function (item) {
                  item = item.trim();
                  var ignoreList = ['#', 'LOCK', 'UNLOCK'];
                  var _iteratorNormalCompletion = true;
                  var _didIteratorError = false;
                  var _iteratorError = undefined;

                  try {
                    for (var _iterator = (0, _getIterator3.default)(ignoreList), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                      var it = _step.value;

                      if (item.indexOf(it) === 0) {
                        return false;
                      }
                    }
                  } catch (err) {
                    _didIteratorError = true;
                    _iteratorError = err;
                  } finally {
                    try {
                      if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                      }
                    } finally {
                      if (_didIteratorError) {
                        throw _iteratorError;
                      }
                    }
                  }

                  return true;
                }).join(' ');
                content = content.replace(/\/\*.*?\*\//g, '').replace(/fk_/g, this.dbConfig.prefix || '');

                //导入数据
                model = this.getModel();
                content = content.split(';');
                _context.prev = 15;
                _iteratorNormalCompletion2 = true;
                _didIteratorError2 = false;
                _iteratorError2 = undefined;
                _context.prev = 19;
                _iterator2 = (0, _getIterator3.default)(content);

              case 21:
                if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                  _context.next = 31;
                  break;
                }

                item = _step2.value;

                item = item.trim();

                if (!item) {
                  _context.next = 28;
                  break;
                }

                think.log(item);
                _context.next = 28;
                return model.query(item);

              case 28:
                _iteratorNormalCompletion2 = true;
                _context.next = 21;
                break;

              case 31:
                _context.next = 37;
                break;

              case 33:
                _context.prev = 33;
                _context.t0 = _context['catch'](19);
                _didIteratorError2 = true;
                _iteratorError2 = _context.t0;

              case 37:
                _context.prev = 37;
                _context.prev = 38;

                if (!_iteratorNormalCompletion2 && _iterator2.return) {
                  _iterator2.return();
                }

              case 40:
                _context.prev = 40;

                if (!_didIteratorError2) {
                  _context.next = 43;
                  break;
                }

                throw _iteratorError2;

              case 43:
                return _context.finish(40);

              case 44:
                return _context.finish(37);

              case 45:
                _context.next = 51;
                break;

              case 47:
                _context.prev = 47;
                _context.t1 = _context['catch'](15);

                think.log(_context.t1);
                return _context.abrupt('return', _promise2.default.reject('数据表导入失败，请在控制台下查看具体的错误信息，并在 GitHub 上发 issue。'));

              case 51:

                think.log('before clear data');

                //清除已有的数据内容
                promises = ['cate', 'post', 'post_cate', 'post_tag', 'tag', 'user'].map(function (item) {
                  var modelInstance = _this2.getModel(item);
                  if (modelInstance) {
                    modelInstance.where('1=1').delete();
                  }
                });
                _context.next = 55;
                return _promise2.default.all(promises);

              case 55:
                optionsModel = this.getModel('options');
                _context.next = 58;
                return optionsModel.where('1=1').update({ value: '' });

              case 58:
                salt = think.uuid(10) + '!@#$%^&*';

                this.password_salt = salt;

                _context.next = 62;
                return optionsModel.updateOptions('navigation', (0, _stringify2.default)([{ 'label': '首页', 'url': '/', 'option': 'home' }, { 'label': '归档', 'url': '/archives/', 'option': 'archive' }, { 'label': '标签', 'url': '/tags', 'option': 'tags' }, { 'label': '关于', 'url': '/about', 'option': 'user' }, { 'label': '友链', 'url': '/links', 'option': 'link' }]));

              case 62:
                _context.next = 64;
                return optionsModel.updateOptions('password_salt', salt);

              case 64:
                _context.next = 66;
                return optionsModel.updateOptions('title', 'FireKylin 系统');

              case 66:
                _context.next = 68;
                return optionsModel.updateOptions('logo_url', '/static/img/firekylin.jpg');

              case 68:
                _context.next = 70;
                return optionsModel.updateOptions('theme', 'firekylin');

              case 70:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this, [[15, 47], [19, 33, 37, 45], [38,, 40, 44]]);
      }));

      function insertData() {
        return _ref.apply(this, arguments);
      }

      return insertData;
    }()
    /**
     * update config
     * @return {[type]} [description]
     */

  }, {
    key: 'updateConfig',
    value: function updateConfig() {
      var data = {
        type: 'mysql',
        adapter: {
          mysql: this.dbConfig
        }
      };
      var content = '\n      "use strict";\n      exports.__esModule = true;\n      exports.default = ' + (0, _stringify2.default)(data, undefined, 4) + '\n    ';

      var dbConfigFile = void 0;
      try {
        var srcPath = _path2.default.join(think.ROOT_PATH, 'src/common/config');
        _fs2.default.statSync(srcPath);
        dbConfigFile = _path2.default.join(srcPath, 'db.js');
      } catch (e) {
        dbConfigFile = _path2.default.join(think.APP_PATH, '/common/config/db.js');
      }
      _fs2.default.writeFileSync(dbConfigFile, content);
      think.config('db', data);
    }
    /**
     * create account
     * @return {[type]} [description]
     */

  }, {
    key: 'createAccount',
    value: function () {
      var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2() {
        var password, model, data;
        return _regenerator2.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                password = think.md5(this.password_salt + this.accountConfig.password);
                model = this.getModel('user', 'admin');
                data = {
                  username: this.accountConfig.username,
                  password: password,
                  email: '',
                  type: 1,
                  status: 1,
                  ip: this.ip
                };
                _context2.next = 5;
                return model.addUser(data);

              case 5:
              case 'end':
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function createAccount() {
        return _ref2.apply(this, arguments);
      }

      return createAccount;
    }()
    /**
     * run
     * @return {[type]} [description]
     */

  }, {
    key: 'run',
    value: function () {
      var _ref3 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3() {
        var optionsModel;
        return _regenerator2.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.checkDbInfo();

              case 2:
                _context3.next = 4;
                return this.insertData();

              case 4:
                _context3.next = 6;
                return this.createAccount();

              case 6:
                this.updateConfig();
                firekylin.setInstalled();
                optionsModel = this.getModel('options');
                _context3.next = 11;
                return optionsModel.getOptions(true);

              case 11:
              case 'end':
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function run() {
        return _ref3.apply(this, arguments);
      }

      return run;
    }()
  }]);
  return _class;
}(think.service.base);

exports.default = _class;