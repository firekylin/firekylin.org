'use strict';
/**
 * config
 */

exports.__esModule = true;
exports.default = {
  //key: value
};