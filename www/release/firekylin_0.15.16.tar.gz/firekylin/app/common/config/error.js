'use strict';
/**
 * err config
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  //key: value
  key: 'errno', //error number
  msg: 'errmsg' //error message
};