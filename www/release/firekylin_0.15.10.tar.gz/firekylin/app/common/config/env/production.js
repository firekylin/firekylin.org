'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  cluster_on: 1
};