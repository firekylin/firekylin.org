'use strict';
/**
 * config
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  //key: value
};